Huge Small File v 1.0

This is a freeware application which creates fake huge files on a NTFS disk which can be shared using common filesharing clients like DC++. Using Huge Small File you can saftly share legal content.

This application works only on Windows NT/2000/XP/2003 systems ON NTFS partitions.


How to use it: Start the application ON NTFS PARTITION !!! and press on the Generate button. In this way you can create in a moment up to 4GB file which takes only 4KBytes on disk. See HugeSmallFile.png screenshot.

Have Fun!